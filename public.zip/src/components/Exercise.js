import React, {useState} from 'react';
import {useHistory} from 'react-router-dom';

import {Modal} from 'react-bootstrap';


import '../assets/bootstrap/css/bootstrap.min.css';
import '../assets/fonts/ionicons.min.css';
import '../assets/css/Admin.css';


function Exercise(props){

    const background_color = "rgba(4, 13, 43, 0.8)";

    let exerciseTemplateTypea = ["Upper body", "Lower body", "Back/Core"]
    let exerciseTemplatesa = ["Template 1", "Template 2", "Template 3"];
    let exerciseTypesa = ["Cardio Equipment", "Table Exercise", "Balance Exercise", "Stretching"];

    var [exerciseTemplateType, setExerciseTemplateType] = useState(exerciseTemplateTypea);
    var [exerciseTemplates, setExerciseTemplates] = useState(exerciseTemplatesa);
    var [exerciseTypes, setExerciseTypes] = useState(exerciseTypesa);
    var [isExerciseModalOpen, exerciseModalToggle] = useState(false);

    const loadTemplates = (event) => {
        
        let tmp = [];
        switch(event.target.value){
            case "Upper body":
                tmp = ["U Temp 1", "U Temp 2", "U Temp 3", "U Temp 4"];
                setExerciseTemplates(tmp);
            break;
            case "Lower body":
                tmp = ["L Temp 1", "L Temp 2", "L Temp 3", "L Temp 4"];
                setExerciseTemplates(tmp);
            break;
            case "Back/Core":
                tmp = ["B/C Temp 1", "B/C Temp 2", "B/C Temp 3", "B/C Temp 4"];
                setExerciseTemplates(tmp);
            break;
            default:
                tmp = [""];
                setExerciseTemplates(tmp);
            break;
        }

    }

    const loadExerciseTypes = (event) => {
       
        let tmp = [];
        switch(event.target.value){
            case "U Temp 1":
                tmp = ["Cardio Equipment", "Table Exercise"];
                setExerciseTypes(tmp);
            break;
            case "U Temp 2":
                tmp = ["Cardio Equipment", "Table Exercise", "Balance Exercise"];
                setExerciseTypes(tmp);
            break;
            case "U Temp 3":
                tmp = ["Cardio Equipment", "Table Exercise", "Balance Exercise", "Stretching"];
                setExerciseTypes(tmp);
            break;
            case "U Temp 4":
                tmp = [ "Table Exercise", "Stretching"];
                setExerciseTypes(tmp);
            break;
            default:
                tmp = [""];
                setExerciseTypes(tmp);
            break;
        }

    }

    const selectExercisesHandler = (event) => {
        
        let tmp = [];
        switch(event.target.value){
            case "Cardio Equipment":
                tmp = ["Cardio Equipment", "Table Exercise"];
                setExerciseTypes(tmp);
            break;
            case "Table Exercise":
                tmp = ["Cardio Equipment", "Table Exercise", "Balance Exercise"];
                setExerciseTypes(tmp);
            break;
            case "Balance Exercise":
                tmp = ["Cardio Equipment", "Table Exercise", "Balance Exercise", "Stretching"];
                setExerciseTypes(tmp);
            break;
            case "Stretching":
                tmp = [ "Table Exercise", "Stretching"];
                setExerciseTypes(tmp);
            break;
            default:
                tmp = [""];
                setExerciseTypes(tmp);
            break;
        }

        exerciseModalToggle(true);
    }

    return <div className='admin'>
                {/* Modal 1 this modal is for Exercise Sub Types*/}
                <Modal show={isExerciseModalOpen}
                    onHide = {()=> exerciseModalToggle(false)}
                    size="md"
                    aria-labelledby="contained-modal-title-vcenter"
                    centered
                    >
                    <Modal.Header closeButton>
                        <h2 className="text-center" style={{color:background_color}}><strong>Exercises</strong></h2>
                    </Modal.Header>
                    <Modal.Body>
                        <p>Hello</p>
                    </Modal.Body>
                </Modal>
          
                <div className="container">
                    <div className='row'>
                        <div className="col-8 offset-0 col-md-4 offset-md-3 col-lg-3 offset-lg-3 col-xl-3  offset-xl-2 card">
                            <label style={{color:background_color}} >Patient Name: John</label>
                            <label style={{color:background_color}} >Diagnosis: </label>
                            <label style={{color:background_color}} >Date: Jan 2, 2020</label>
                            
                        </div>
                    </div>
                    <div className="row">            
                        <div className="col-12 offset-0 col-sm-6 offset-sm-0 col-md-4 offset-md-4 col-lg-3 offset-lg-6 col-xl-2 offset-xl-8 dropdown">
                            <select className="btn btn-primary dropdown-toggle" type="button" style={{width:"100%", backgroundColor:background_color}} onChange={loadTemplates}>
                                <option className="dropoptions" value="" style={{backgroundColor:"white", color:"black"}} defaultValue>Template Type</option>   
                                    {
                                    exerciseTemplateType.map( (extemptype, index) => {
                                        return <option key = {index} value={extemptype} style={{backgroundColor:"white", color:"black"}}>{extemptype}</option>
                                        })
                                    } 
                            </select>
                        </div>
                        
                        <div className="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 dropdown">
                            <select className="col-12 btn btn-primary dropdown-toggle" type="button" style={{width:"100%", backgroundColor:background_color}} onChange={loadExerciseTypes}>
                                <option className="dropoptions" value="" style={{backgroundColor:"white", color:"black"}} defaultValue>Templates</option>   
                                    {
                                    exerciseTemplates.map( (extemptype, index) => {
                                        return <option key = {index} value={extemptype} style={{backgroundColor:"white", color:"black"}}>{extemptype}</option>
                                        })
                                    } 
                            </select>
                        </div>
                    </div>

                    <div className="row top-buffer">        
                        <div className="col-12 offset-0 col-md-9 offset-md-3 col-lg-9 offset-lg-3 col-xl-10  offset-xl-2 card">
                            <div className="card-body float-left">                           
                                <div className="row">
                                    <div className="col-10 offset-2 col-sm-7 offset-sm-5 col-md-5 offset-md-7 col-lg-4 offset-lg-8 col-xl-3 offset-xl-9 dropdown">
                                        <select className="btn btn-primary dropdown-toggle" type="button" style={{width:"100%", backgroundColor:background_color}} onChange={selectExercisesHandler}>
                                            <option className="dropoptions" value="" style={{backgroundColor:"white", color:"black"}} defaultValue>Exercise Types</option>   
                                            {
                                            exerciseTypes.map( (extemptype, index) => {
                                                return <option key = {index} value={extemptype} style={{backgroundColor:"white", color:"black"}}>{extemptype}</option>
                                                })
                                            }
                                        </select>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-12 card">  
                                        <div className="row">
                                            <div className="col-12">
                                            <center>
                                            <label style={{color:background_color, fontSize:"25px"}}>Exercises</label>                                 
                                            </center>
                                            </div>
                                        </div>   
                                        Hello world
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

           </div>

}
export default Exercise;