import {ADMIN_PASSWORD_MODAL_OPEN, ADMIN_PASSWORD_MODAL_CLOSE} from "../constants/modal";

import {ADMIN_PROFILE_INFO_MODAL_OPEN, ADMIN_PROFILE_INFO_MODAL_CLOSE} from "../constants/modal";

const initialState = {
    isPasswordChange: false,
    isAccountInfoOpen: false
};

//  this reducer function is for CLinic info
export default function (state = initialState, action) {
  const { type } = action;

  switch (type) {
    case ADMIN_PASSWORD_MODAL_OPEN:
      return { ...state, isPasswordChange: action.isPasswordChange };

    case ADMIN_PASSWORD_MODAL_CLOSE:
      return { ...state, isPasswordChange: action.isPasswordChange };
      
    case ADMIN_PROFILE_INFO_MODAL_OPEN:
      return { ...state, isAccountInfoOpen: action.isAccountInfoOpen};
      
    case ADMIN_PROFILE_INFO_MODAL_CLOSE:
    return { ...state, isAccountInfoOpen: action.isAccountInfoOpen};

    default:
      return state;
  }
}